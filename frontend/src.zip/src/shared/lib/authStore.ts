import { create } from 'zustand';
// --- CORRECTION : Import des fonctions API nécessaires ---
import { 
    login as apiLogin, 
    register as apiRegister, 
    getCurrentUser,
    logout as apiLogout // Assurez-vous d'avoir une fonction logout dans votre apiClient
} from '@shared/lib';
import type { AuthCredentials, RegisterCredentials, User } from '@shared/types/api.v1';

// L'interface qui définit la "forme" de notre store
interface AuthState {
  // Le token n'est plus stocké côté client
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: AuthCredentials) => Promise<void>;
  register: (credentials: RegisterCredentials) => Promise<void>;
  logout: () => Promise<void>; // Logout est maintenant une opération asynchrone
  checkAuth: () => Promise<void>;
  forceLogout: () => void; // Nouvelle fonction pour forcer la déconnexion
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true, // L'application commence en état de chargement

  login: async (credentials: AuthCredentials) => {
    try {
      // 1. Appelle l'API de login. Le backend s'occupe de poser le cookie.
      await apiLogin(credentials);
      // 2. Récupère les informations de l'utilisateur pour mettre à jour l'état de l'UI.
      const user = await getCurrentUser();
      set({ user, isAuthenticated: true, isLoading: false });
    } catch (error) {
      // En cas d'erreur, on s'assure que l'état est propre
      set({ user: null, isAuthenticated: false, isLoading: false });
      throw error;
    }
  },

  register: async (credentials: RegisterCredentials) => {
    await apiRegister(credentials);
    // Après l'inscription, on connecte directement l'utilisateur.
    await get().login({ username: credentials.username, password: credentials.password });
  },

  logout: async () => {
    try {
      // Appelle le backend pour qu'il supprime le cookie HttpOnly.
      await apiLogout();
    } catch (error) {
      // Même si l'API échoue, on force la déconnexion côté client
      console.warn('Erreur lors de la déconnexion API:', error);
    } finally {
      // Met à jour l'état de l'application pour refléter la déconnexion.
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },

  forceLogout: () => {
    // Force la déconnexion sans appeler l'API (utile en cas d'erreur 401)
    set({ user: null, isAuthenticated: false, isLoading: false });
  },

  checkAuth: async () => {
    set({ isLoading: true });
    try {
      // Tente de récupérer l'utilisateur. Si l'utilisateur a un cookie valide,
      // cette requête réussira.
      const user = await getCurrentUser();
      set({ user, isAuthenticated: true, isLoading: false });
    } catch (error) {
      // Si la requête échoue (ex: 401 Unauthorized), cela signifie que l'utilisateur
      // n'est pas connecté. On s'assure que l'état est propre.
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },
}));
# 🎨 Composants de Démonstration - Mapping Studio V2.2

Ce dossier contient tous les composants de démonstration pour le Mapping Studio V2.2, permettant aux utilisateurs de tester et découvrir les fonctionnalités avancées.

## 📁 Structure des Composants

### **1. 🚀 DemoWorkbench** (`DemoWorkbench.tsx`)
**Composant principal de démonstration** avec interface complète et statut des services.

**Fonctionnalités :**
- ✅ Vérification du statut des services (Backend, Frontend, Database, Elasticsearch)
- 🎨 Sélecteur entre Studio et Workbench
- 📊 Interface responsive avec design moderne
- 🐛 Panel de debug en mode développement

**Utilisation :**
```tsx
import { DemoWorkbench } from '@features/mappings/demo';

<DemoWorkbench />
```

### **2. 📄 DemoPage** (`DemoPage.tsx`)
**Page complète de démonstration** avec métadonnées et SEO optimisé.

**Fonctionnalités :**
- 🔍 Métadonnées SEO avec React Helmet
- 🎯 Titre et description optimisés
- 📱 Interface responsive complète

**Utilisation :**
```tsx
import { DemoPage } from '@features/mappings/demo';

// Dans le routeur
<Route path="/demo" element={<DemoPage />} />
```

### **3. ⚡ QuickDemo** (`QuickDemo.tsx`)
**Démonstration rapide et interactive** avec étapes guidées.

**Fonctionnalités :**
- 📋 4 étapes de démonstration guidée
- 🔄 Actions interactives à chaque étape
- 📊 Aperçu en temps réel du mapping
- 🎨 Interface modale élégante

**Utilisation :**
```tsx
import { QuickDemo } from '@features/mappings/demo';

const [isOpen, setIsOpen] = useState(false);

{isOpen && <QuickDemo onClose={() => setIsOpen(false)} />}
```

### **4. 🎯 FloatingDemo** (`FloatingDemo.tsx`)
**Composant de démonstration flottant** intégrable dans n'importe quelle interface.

**Fonctionnalités :**
- 📍 4 positions configurables (top-right, top-left, bottom-right, bottom-left)
- 🎨 3 variantes visuelles (button, badge, icon)
- 🔗 Intégration facile dans d'autres composants
- 📱 Responsive et adaptatif

**Utilisation :**
```tsx
import { FloatingDemo } from '@features/mappings/demo';

// Bouton flottant en bas à droite
<FloatingDemo position="bottom-right" variant="button" />

// Badge en haut à gauche
<FloatingDemo position="top-left" variant="badge" />

// Icône en haut à droite
<FloatingDemo position="top-right" variant="icon" />
```

## 🚀 Intégration dans l'Application

### **1. Route Principale**
```tsx
// Dans App.tsx
<Route path="/demo" element={<DemoPage />} />
```

### **2. Navigation dans le Header**
```tsx
// Lien automatiquement ajouté dans Header.tsx
<Link to="/demo" className={styles.navLink}>
  🎨 Démonstration
</Link>
```

### **3. Bouton Flottant Global**
```tsx
// Dans App.tsx - visible sur toutes les pages
<FloatingDemo position="bottom-right" variant="button" />
```

## 🎨 Personnalisation

### **1. Styles CSS**
Tous les composants utilisent des modules CSS avec :
- 🎨 Design moderne avec gradients et ombres
- 📱 Responsive design complet
- 🔄 Animations fluides et transitions
- 🎯 Thème cohérent avec l'application

### **2. Configuration des Positions**
```tsx
// Positions disponibles pour FloatingDemo
position="top-right"    // Haut à droite
position="top-left"     // Haut à gauche
position="bottom-right" // Bas à droite
position="bottom-left"  // Bas à gauche
```

### **3. Variantes Visuelles**
```tsx
// Variantes disponibles pour FloatingDemo
variant="button"  // Bouton complet avec texte
variant="badge"   // Badge compact avec icône
variant="icon"    // Icône circulaire simple
```

## 🔧 Développement

### **1. Ajout d'un Nouveau Composant**
1. Créer le composant React dans le dossier `demo/`
2. Créer le fichier de styles `.module.scss`
3. Ajouter l'export dans `index.ts`
4. Documenter dans ce README

### **2. Tests et Validation**
```bash
# Tester les routes de démonstration
cd backend
python test-demo-routes.py

# Tester l'interface frontend
cd frontend
npm run dev
# Ouvrir http://localhost:5173/demo
```

### **3. Débogage**
- 🐛 Panel de debug en mode développement
- 📊 Console avec informations détaillées
- 🔍 Vérification du statut des services

## 📱 Responsive Design

Tous les composants sont optimisés pour :
- 🖥️ **Desktop** : Interface complète avec toutes les fonctionnalités
- 📱 **Mobile** : Adaptation automatique des tailles et positions
- 📱 **Tablet** : Interface intermédiaire optimisée

## 🎯 Bonnes Pratiques

### **1. Performance**
- ⚡ Chargement lazy des composants lourds
- 🔄 Mémoisation des calculs coûteux
- 📊 Optimisation des re-renders

### **2. Accessibilité**
- ♿ Support des lecteurs d'écran
- ⌨️ Navigation au clavier
- 🎨 Contraste et lisibilité optimisés

### **3. Internationalisation**
- 🌍 Support multilingue (préparé)
- 📅 Formatage des dates localisé
- 🔢 Formatage des nombres adapté

## 🔗 Liens Utiles

- **Backend API** : `/api/v1/demo/*`
- **Frontend Route** : `/demo`
- **Documentation** : `docs/DEMO_WORKBENCH_GUIDE.md`
- **Tests** : `test-demo-routes.py`

---

**Version** : 2.2.0  
**Dernière mise à jour** : Août 2024  
**Statut** : ✅ **Complet et Documenté**

import React, { useState, useEffect } from 'react';
import styles from './QuickDemo.module.scss';

interface QuickDemoProps {
  onClose?: () => void;
}

export const QuickDemo: React.FC<QuickDemoProps> = ({ onClose }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [demoData, setDemoData] = useState({
    name: 'Mapping de démonstration',
    version: '2.2',
    fields: ['id', 'name', 'email', 'age']
  });

  useEffect(() => {
    // Animation d'entrée
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const steps = [
    {
      title: '🎯 Création de Mapping',
      description: 'Définir la structure des champs et leurs transformations',
      action: () => setDemoData(prev => ({ ...prev, fields: [...prev.fields, 'status'] }))
    },
    {
      title: '🔧 Configuration des Opérations',
      description: 'Ajouter des opérations de transformation et de validation',
      action: () => setDemoData(prev => ({ ...prev, version: '2.2.1' }))
    },
    {
      title: '🧪 Test et Validation',
      description: 'Tester le mapping avec des données réelles',
      action: () => setDemoData(prev => ({ ...prev, status: 'validated' }))
    },
    {
      title: '📤 Export et Déploiement',
      description: 'Exporter vers Elasticsearch et monitorer',
      action: () => setDemoData(prev => ({ ...prev, deployed: true }))
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      steps[currentStep].action();
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => onClose?.(), 300);
  };

  return (
    <div className={`${styles.quickDemo} ${isVisible ? styles.visible : ''}`}>
      <div className={styles.demoHeader}>
        <h2>🚀 Démonstration Rapide - Mapping Studio V2.2</h2>
        <button className={styles.closeButton} onClick={handleClose}>
          ×
        </button>
      </div>

      <div className={styles.demoContent}>
        <div className={styles.stepIndicator}>
          {steps.map((step, index) => (
            <div
              key={index}
              className={`${styles.step} ${index === currentStep ? styles.active : ''} ${index < currentStep ? styles.completed : ''}`}
            >
              <span className={styles.stepNumber}>{index + 1}</span>
              <span className={styles.stepTitle}>{step.title}</span>
            </div>
          ))}
        </div>

        <div className={styles.currentStep}>
          <h3>{steps[currentStep].title}</h3>
          <p>{steps[currentStep].description}</p>
          
          <div className={styles.demoPreview}>
            <h4>📊 Aperçu du Mapping</h4>
            <pre className={styles.jsonPreview}>
              {JSON.stringify(demoData, null, 2)}
            </pre>
          </div>
        </div>

        <div className={styles.demoActions}>
          <button
            className={styles.actionButton}
            onClick={handlePrevious}
            disabled={currentStep === 0}
          >
            ← Précédent
          </button>
          
          <button
            className={styles.actionButton}
            onClick={handleNext}
            disabled={currentStep === steps.length - 1}
          >
            Suivant →
          </button>
        </div>
      </div>

      <div className={styles.demoFooter}>
        <p>
          <strong>Étape {currentStep + 1} sur {steps.length}</strong> - 
          {currentStep === steps.length - 1 ? ' Démonstration terminée !' : ' Cliquez sur Suivant pour continuer'}
        </p>
      </div>
    </div>
  );
};

export default QuickDemo;

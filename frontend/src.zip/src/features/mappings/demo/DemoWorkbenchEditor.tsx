import React, { useState } from 'react';
import styles from './DemoWorkbenchEditor.module.scss';

export const DemoWorkbenchEditor: React.FC = () => {
  const [mappingCode, setMappingCode] = useState(`{
  "version": "2.2",
  "name": "Mapping de démonstration",
  "description": "Mapping V2.2 pour Elasticsearch",
  "fields": {
    "user_id": {
      "type": "keyword",
      "description": "Identifiant unique de l'utilisateur"
    },
    "full_name": {
      "type": "text",
      "analyzer": "standard",
      "fields": {
        "keyword": {
          "type": "keyword",
          "ignore_above": 256
        }
      }
    },
    "email": {
      "type": "keyword",
      "normalizer": "lowercase"
    },
    "age": {
      "type": "integer",
      "min": 0,
      "max": 150
    },
    "created_at": {
      "type": "date",
      "format": "strict_date_optional_time||epoch_millis"
    }
  },
  "settings": {
    "number_of_shards": 1,
    "number_of_replicas": 0
  }
}`);

  const [validationResult, setValidationResult] = useState<string | null>(null);
  const [isValidating, setIsValidating] = useState(false);

  const handleCodeChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMappingCode(event.target.value);
    setValidationResult(null);
  };

  const validateMapping = () => {
    setIsValidating(true);
    
    // Simulation de validation
    setTimeout(() => {
      try {
        JSON.parse(mappingCode);
        setValidationResult('✅ Mapping JSON valide !');
      } catch (error) {
        setValidationResult('❌ Erreur de syntaxe JSON');
      }
      setIsValidating(false);
    }, 1000);
  };

  const formatCode = () => {
    try {
      const parsed = JSON.parse(mappingCode);
      setMappingCode(JSON.stringify(parsed, null, 2));
      setValidationResult('✅ Code formaté avec succès !');
    } catch (error) {
      setValidationResult('❌ Impossible de formater - JSON invalide');
    }
  };

  const exportMapping = () => {
    try {
      const parsed = JSON.parse(mappingCode);
      const blob = new Blob([JSON.stringify(parsed, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mapping-v2.2.json';
      a.click();
      URL.revokeObjectURL(url);
      setValidationResult('📤 Mapping exporté avec succès !');
    } catch (error) {
      setValidationResult('❌ Erreur lors de l\'export');
    }
  };

  return (
    <div className={styles.workbenchEditor}>
      <div className={styles.editorHeader}>
        <h2>🔧 Workbench de Mapping V2.2 - Mode Démo</h2>
        <p>Éditeur de code avancé pour créer et valider des mappings Elasticsearch</p>
      </div>

      <div className={styles.editorContent}>
        {/* Barre d'outils */}
        <div className={styles.toolbar}>
          <button 
            className={styles.toolButton}
            onClick={validateMapping}
            disabled={isValidating}
          >
            {isValidating ? '🔄 Validation...' : '🧪 Valider'}
          </button>
          
          <button 
            className={styles.toolButton}
            onClick={formatCode}
          >
            🎨 Formater
          </button>
          
          <button 
            className={styles.toolButton}
            onClick={exportMapping}
          >
            📤 Exporter
          </button>
        </div>

        {/* Éditeur de code */}
        <div className={styles.codeEditor}>
          <div className={styles.editorTabs}>
            <span className={styles.activeTab}>mapping.json</span>
          </div>
          
          <textarea
            value={mappingCode}
            onChange={handleCodeChange}
            placeholder="Entrez votre mapping V2.2 ici..."
            className={styles.codeTextarea}
            spellCheck={false}
          />
        </div>

        {/* Résultats de validation */}
        <div className={styles.validationPanel}>
          <h3>📊 Résultats</h3>
          
          {validationResult && (
            <div className={styles.validationResult}>
              <span>{validationResult}</span>
            </div>
          )}
          
          <div className={styles.validationInfo}>
            <h4>ℹ️ Informations</h4>
            <ul>
              <li><strong>Version :</strong> Mapping DSL V2.2</li>
              <li><strong>Support :</strong> Tous les types Elasticsearch 8.x</li>
              <li><strong>Validation :</strong> Syntaxe JSON + règles V2.2</li>
              <li><strong>Export :</strong> Format JSON standard</li>
            </ul>
          </div>
        </div>
      </div>

      <div className={styles.demoNotice}>
        <p>🎯 <strong>Mode Démonstration :</strong> Cet éditeur simule le comportement du Mapping Workbench V2.2. 
        La validation, le formatage et l'export sont simulés pour la démonstration.</p>
      </div>
    </div>
  );
};

export default DemoWorkbenchEditor;

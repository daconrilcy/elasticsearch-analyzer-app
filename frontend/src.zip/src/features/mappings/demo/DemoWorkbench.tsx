import React, { useState, useEffect } from 'react';
import { DemoStudio } from './DemoStudio';
import { DemoWorkbenchEditor } from './DemoWorkbenchEditor';
import { MAPPING_STUDIO_CONFIG } from '../config';
import styles from './DemoWorkbench.module.scss';

interface DemoStatus {
  backend: boolean;
  frontend: boolean;
  database: boolean;
  elasticsearch: boolean;
}

export const DemoWorkbenchContainer: React.FC = () => {
  const [activeDemo, setActiveDemo] = useState<'studio' | 'workbench'>('studio');
  const [demoStatus, setDemoStatus] = useState<DemoStatus>({
    backend: false,
    frontend: true,
    database: false,
    elasticsearch: false
  });
  const [isLoading, setIsLoading] = useState(true);
  const [apiError, setApiError] = useState<string | null>(null);

  // Vérifier le statut des services
  useEffect(() => {
    const checkServices = async () => {
      try {
        const apiBase = import.meta.env.VITE_API_BASE || 'http://localhost:8000';
        console.log('🔍 Vérification des services avec API:', apiBase);
        
        // Vérifier le backend
        const backendResponse = await fetch(`${apiBase}/api/v1/demo/status`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });
        
        if (backendResponse.ok) {
          const status = await backendResponse.json();
          console.log('✅ Statut du backend:', status);
          
          setDemoStatus(prev => ({
            ...prev,
            backend: status.components?.backend?.includes('✅') || false,
            database: status.components?.database?.includes('✅') || false,
            elasticsearch: status.components?.elasticsearch?.includes('✅') || false
          }));
          setApiError(null);
        } else {
          console.warn('⚠️ Backend accessible mais erreur de statut:', backendResponse.status);
          setDemoStatus(prev => ({ ...prev, backend: true }));
          setApiError(`Erreur ${backendResponse.status}: ${backendResponse.statusText}`);
        }
      } catch (error) {
        console.warn('❌ Impossible de vérifier le statut des services:', error);
        setApiError('Impossible de se connecter au backend');
        setDemoStatus(prev => ({ ...prev, backend: false }));
      } finally {
        setIsLoading(false);
      }
    };

    checkServices();
  }, []);

  // Vérifier la configuration
  useEffect(() => {
    console.log('🎨 Mapping Studio V2.2 Configuration:', MAPPING_STUDIO_CONFIG);
    console.log('🌐 Environment:', {
      VITE_API_BASE: import.meta.env.VITE_API_BASE,
      DEV: import.meta.env.DEV,
      PROD: import.meta.env.PROD,
    });
  }, []);

  if (isLoading) {
    return (
      <div className={styles.loadingContainer}>
        <div className={styles.spinner}></div>
        <p>🚀 Initialisation du Mapping Studio V2.2...</p>
      </div>
    );
  }

  return (
    <div className={styles.demoWorkbench}>
      {/* En-tête avec statut des services */}
      <header className={styles.header}>
        <div className={styles.titleSection}>
          <h1>🎨 Mapping Studio V2.2 - Démonstration</h1>
          <p>Interface complète intégrant toutes les fonctionnalités V2.2</p>
          
          {/* Affichage des erreurs d'API */}
          {apiError && (
            <div className={styles.apiError}>
              <span>⚠️ {apiError}</span>
              <small>Mode démo avec fonctionnalités limitées</small>
            </div>
          )}
        </div>
        
        <div className={styles.statusSection}>
          <div className={styles.statusGrid}>
            <div className={`${styles.statusItem} ${demoStatus.backend ? styles.healthy : styles.unhealthy}`}>
              <span className={styles.statusIcon}>
                {demoStatus.backend ? '✅' : '❌'}
              </span>
              <span className={styles.statusLabel}>Backend</span>
            </div>
            <div className={`${styles.statusItem} ${demoStatus.frontend ? styles.healthy : styles.unhealthy}`}>
              <span className={styles.statusIcon}>
                {demoStatus.frontend ? '✅' : '❌'}
              </span>
              <span className={styles.statusLabel}>Frontend</span>
            </div>
            <div className={`${styles.statusItem} ${demoStatus.database ? styles.healthy : styles.unhealthy}`}>
              <span className={styles.statusIcon}>
                {demoStatus.database ? '✅' : '❌'}
              </span>
              <span className={styles.statusLabel}>Database</span>
            </div>
            <div className={`${styles.statusItem} ${demoStatus.elasticsearch ? styles.healthy : styles.unhealthy}`}>
              <span className={styles.statusIcon}>
                {demoStatus.elasticsearch ? '✅' : '❌'}
              </span>
              <span className={styles.statusLabel}>Elasticsearch</span>
            </div>
          </div>
        </div>
      </header>

      {/* Sélecteur de démonstration */}
      <div className={styles.demoSelector}>
        <button
          className={`${styles.demoButton} ${activeDemo === 'studio' ? styles.active : ''}`}
          onClick={() => setActiveDemo('studio')}
        >
          🎨 Studio V2.2
          <span className={styles.demoDescription}>
            Interface graphique drag & drop
          </span>
        </button>
        <button
          className={`${styles.demoButton} ${activeDemo === 'workbench' ? styles.active : ''}`}
          onClick={() => setActiveDemo('workbench')}
        >
          🔧 Workbench V2.2
          <span className={styles.demoDescription}>
            Éditeur de code avancé
          </span>
        </button>
      </div>

      {/* Contenu de la démonstration */}
      <main className={styles.demoContent}>
        {activeDemo === 'studio' && <DemoStudio />}
        {activeDemo === 'workbench' && <DemoWorkbenchEditor />}
      </main>
      
      {/* Informations de debug en mode développement */}
      {import.meta.env.DEV && (
        <div className={styles.debugPanel}>
          <div className={styles.debugHeader}>
            <span>🚀 Debug Info</span>
            <button 
              className={styles.debugToggle}
              onClick={() => {
                const panel = document.querySelector(`.${styles.debugPanel}`);
                panel?.classList.toggle(styles.collapsed);
              }}
            >
              {document.querySelector(`.${styles.debugPanel}`)?.classList.contains(styles.collapsed) ? '▶️' : '▼'}
            </button>
          </div>
          <div className={styles.debugContent}>
            <div>Mode: Développement</div>
            <div>API: {import.meta.env.VITE_API_BASE || 'http://localhost:8000'}</div>
            <div>Version: {MAPPING_STUDIO_CONFIG.api?.baseUrl?.includes('v2') ? '2.2' : '2.2'}</div>
            <div>Demo: {activeDemo === 'studio' ? 'Studio' : 'Workbench'}</div>
            <div>Backend: {demoStatus.backend ? 'Connecté' : 'Déconnecté'}</div>
            {apiError && <div>Erreur: {apiError}</div>}
          </div>
        </div>
      )}
    </div>
  );
};

export default DemoWorkbenchContainer;

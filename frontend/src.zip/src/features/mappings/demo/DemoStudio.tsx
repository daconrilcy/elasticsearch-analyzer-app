import React, { useState } from 'react';
import styles from './DemoStudio.module.scss';

export const DemoStudio: React.FC = () => {
  const [mapping, setMapping] = useState({
    version: '2.2',
    name: 'Mapping de démonstration',
    fields: [
      {
        name: 'full_name',
        type: 'text',
        pipeline: [
          { id: 'op1', type: 'trim', config: {} },
          { id: 'op2', type: 'cast', config: { target_type: 'keyword' } }
        ]
      },
      {
        name: 'email',
        type: 'keyword',
        pipeline: [
          { id: 'op3', type: 'map', config: { transform: 'lowercase' } }
        ]
      }
    ]
  });

  const [selectedField, setSelectedField] = useState<string | null>(null);

  const handleFieldSelect = (fieldName: string) => {
    setSelectedField(fieldName === selectedField ? null : fieldName);
  };

  const addOperation = (fieldName: string, operationType: string) => {
    setMapping(prev => ({
      ...prev,
      fields: prev.fields.map(field => 
        field.name === fieldName 
          ? {
              ...field,
              pipeline: [...field.pipeline, {
                id: `op${Date.now()}`,
                type: operationType,
                config: {}
              }]
            }
          : field
      )
    }));
  };

  const removeOperation = (fieldName: string, operationId: string) => {
    setMapping(prev => ({
      ...prev,
      fields: prev.fields.map(field => 
        field.name === fieldName 
          ? {
              ...field,
              pipeline: field.pipeline.filter(op => op.id !== operationId)
            }
          : field
      )
    }));
  };

  return (
    <div className={styles.demoStudio}>
      <div className={styles.studioHeader}>
        <h2>🎨 Studio de Mapping V2.2 - Mode Démo</h2>
        <p>Interface graphique pour créer et configurer des mappings Elasticsearch</p>
      </div>

      <div className={styles.studioContent}>
        {/* Panneau des champs */}
        <div className={styles.fieldsPanel}>
          <h3>📋 Champs du Mapping</h3>
          <div className={styles.fieldsList}>
            {mapping.fields.map(field => (
              <div 
                key={field.name}
                className={`${styles.fieldItem} ${selectedField === field.name ? styles.selected : ''}`}
                onClick={() => handleFieldSelect(field.name)}
              >
                <div className={styles.fieldHeader}>
                  <span className={styles.fieldName}>{field.name}</span>
                  <span className={styles.fieldType}>{field.type}</span>
                </div>
                
                {selectedField === field.name && (
                  <div className={styles.fieldOperations}>
                    <h4>🔧 Opérations</h4>
                    {field.pipeline.map(op => (
                      <div key={op.id} className={styles.operationItem}>
                        <span className={styles.operationType}>{op.type}</span>
                        <button
                          className={styles.removeOpButton}
                          onClick={() => removeOperation(field.name, op.id)}
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    
                    <div className={styles.addOperations}>
                      <button onClick={() => addOperation(field.name, 'trim')}>
                        + Trim
                      </button>
                      <button onClick={() => addOperation(field.name, 'lowercase')}>
                        + Lowercase
                      </button>
                      <button onClick={() => addOperation(field.name, 'uppercase')}>
                        + Uppercase
                      </button>
                      <button onClick={() => addOperation(field.name, 'cast')}>
                        + Cast
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Aperçu du mapping */}
        <div className={styles.previewPanel}>
          <h3>📊 Aperçu du Mapping</h3>
          <div className={styles.jsonPreview}>
            <pre>{JSON.stringify(mapping, null, 2)}</pre>
          </div>
          
          <div className={styles.previewActions}>
            <button className={styles.actionButton}>
              💾 Sauvegarder (Démo)
            </button>
            <button className={styles.actionButton}>
              🧪 Valider (Démo)
            </button>
            <button className={styles.actionButton}>
              📤 Exporter (Démo)
            </button>
          </div>
        </div>
      </div>

      <div className={styles.demoNotice}>
        <p>🎯 <strong>Mode Démonstration :</strong> Cette interface simule le comportement du Mapping Studio V2.2. 
        Les actions de sauvegarde, validation et export sont simulées pour la démonstration.</p>
      </div>
    </div>
  );
};

export default DemoStudio;

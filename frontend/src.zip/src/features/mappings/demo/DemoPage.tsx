import React from 'react';
import { DemoWorkbenchContainer } from './DemoWorkbench';

export const DemoPage: React.FC = () => {
  return (
    <DemoWorkbenchContainer />
  );
};

export default DemoPage;

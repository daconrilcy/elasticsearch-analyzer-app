import React, { useState } from 'react';
import { QuickDemo } from './QuickDemo';
import styles from './FloatingDemo.module.scss';

interface FloatingDemoProps {
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
  variant?: 'button' | 'badge' | 'icon';
}

export const FloatingDemo: React.FC<FloatingDemoProps> = ({ 
  position = 'bottom-right',
  variant = 'button'
}) => {
  const [isQuickDemoOpen, setIsQuickDemoOpen] = useState(false);

  const handleOpenQuickDemo = () => {
    setIsQuickDemoOpen(true);
  };

  const handleCloseQuickDemo = () => {
    setIsQuickDemoOpen(false);
  };

  const renderDemoTrigger = () => {
    switch (variant) {
      case 'badge':
        return (
          <div className={styles.demoBadge} onClick={handleOpenQuickDemo}>
            <span className={styles.badgeIcon}>🎨</span>
            <span className={styles.badgeText}>Demo V2.2</span>
          </div>
        );
      
      case 'icon':
        return (
          <button className={styles.demoIcon} onClick={handleOpenQuickDemo}>
            <span className={styles.iconSymbol}>🎨</span>
          </button>
        );
      
      default:
        return (
          <button className={styles.demoButton} onClick={handleOpenQuickDemo}>
            <span className={styles.buttonIcon}>🎨</span>
            <span className={styles.buttonText}>Démonstration</span>
          </button>
        );
    }
  };

  return (
    <>
      <div className={`${styles.floatingDemo} ${styles[position]}`}>
        {renderDemoTrigger()}
      </div>

      {isQuickDemoOpen && (
        <QuickDemo onClose={handleCloseQuickDemo} />
      )}
    </>
  );
};

export default FloatingDemo;

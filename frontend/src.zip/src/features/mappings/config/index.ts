// Configuration du Mapping Studio
export * from './v2.2.config';

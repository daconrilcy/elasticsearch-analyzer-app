import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../../shared/lib/apiClient'; // Chemin corrigé vers le client partagé
import styles from './DemoLauncherPage.module.scss'; // Fichier de style local

export function DemoLauncherPage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleStartDemo = async () => {
    setIsLoading(true);
    setError(null);
    try {
        // CORRECTION : Ajoutez le préfixe "/api/v1" à l'URL
        const response = await apiClient('/api/v1/demo/setup', {
          method: 'POST',
        });

      // La réponse de fetch doit être lue en JSON
      const data = await response.json();
      const { dataset_id, mapping_id } = data;

      if (!dataset_id || !mapping_id) {
        throw new Error("Les ID de la démo n'ont pas été reçus du serveur.");
      }

      // Redirection vers le vrai workbench avec les ID reçus
      navigate(`/datasets/${dataset_id}/mappings/${mapping_id}`);

    } catch (err: any) {
      console.error("Erreur lors de la création de la démo:", err);
      setError(err.message || "Impossible de lancer la session de démo. Veuillez réessayer.");
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <h1 className={styles.title}>
          Démonstration de l'Atelier de Mapping
        </h1>
        <p className={styles.description}>
          Cliquez sur le bouton ci-dessous pour créer un jeu de données et un mapping
          d'exemple. Vous serez ensuite redirigé vers l'atelier de mapping.
        </p>
        <div className={styles.buttonContainer}>
          <button
            className={styles.button}
            onClick={handleStartDemo}
            disabled={isLoading}
          >
            {isLoading ? 'Lancement...' : 'Démarrer la Démo'}
          </button>
          {isLoading && <div className={styles.spinner}></div>}
        </div>
        {error && (
          <p className={styles.error}>
            {error}
          </p>
        )}
      </div>
    </div>
  );
}